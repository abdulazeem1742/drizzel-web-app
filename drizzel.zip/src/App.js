import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import './Responsive.css';
import Header from './components/Header/Header';
import Home from './components/Home/Home';
import Footer from './components/Home/Footer/Footer';

function App() {
  return (
    <>
    <Header />
    <Home />
    <Footer />
    </>
  );
}

export default App;
