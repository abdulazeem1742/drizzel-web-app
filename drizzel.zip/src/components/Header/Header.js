import React, { useState } from 'react';

export default function Header() {
  const [isNavActive, setIsNavActive] = useState(false);

  const toggleNav = () => {
    setIsNavActive(!isNavActive);
  };

  return (
    <header className='header'>
        <div className='container'>
            <div className='navigationBar d_flexSpacebetween'>
                <div className='logoSect'>
                    <a href='javascript:void(0)'>
                        <img src={process.env.PUBLIC_URL + '/assets/images/Drizzel.png'} alt="Drizzel-logo"/>
                    </a>
                </div>
                <div className='navLink_sect'>
                    <ul className={`navLink d_flexStartBetween ${isNavActive ? 'active' : ''}`}>
                        <li>
                            <a href="javascript:void(0)">Work</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">Blog</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">About</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">Careers</a>
                        </li>
                    </ul>
                </div>
                <div className='header_loginSection'>
                    <div className='toggle-btn' onClick={toggleNav}>
                        <img src={process.env.PUBLIC_URL + '/assets/images/menu.png'} alt="menu"/>
                    </div>
                    <ul className='loginBtn d_flexSpacebetween'> 
                        <li>
                            <a href='javascript:void(0)' className='cta cta2'>Sign in</a>
                        </li>
                        <li>
                            <a href='javascript:void(0)' className='cta'>Get Started</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
  )
}
