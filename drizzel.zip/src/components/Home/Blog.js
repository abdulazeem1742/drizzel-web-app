import React from "react";
import Slider from "react-slick";

const Blog = () => {
  const blogData = [
    {
      id: 1,
      image: '/assets/images/blog-img-1.png',
      date: 'Demi Wilkinson • 16 Jan 2022',
      title: 'PM mental models',
      content: 'Mental models are simple expressions of complex processes or relationships.',
      tags: ['Design', 'Research', 'Frameworks'],
    },
    {
      id: 2,
      image: '/assets/images/blog-img-2.png',
      date: 'Candice Wu • 15 Jan 2022',
      title: 'What is Wireframing?',
      content: 'Introduction to Wireframing and its Principles. Learn from the best in the industry.',
      tags: ['Design', 'Research'],
    },
    {
      id: 3,
      image: '/assets/images/blog-img-3.png',
      date: 'Natali Craig • 14 Jan 2022',
      title: 'UX review presentations',
      content: 'How do you create compelling presentations that wow your colleagues and impress your...',
      tags: ['Design', 'Research', 'Frameworks'],
    },
    {
        id: 4,
        image: '/assets/images/blog-img-1.png',
        date: 'Demi Wilkinson • 16 Jan 2022',
        title: 'PM mental models',
        content: 'Mental models are simple expressions of complex processes or relationships.',
        tags: ['Design', 'Research', 'Frameworks'],
      },
      {
        id: 5,
        image: '/assets/images/blog-img-2.png',
        date: 'Candice Wu • 15 Jan 2022',
        title: 'What is Wireframing?',
        content: 'Introduction to Wireframing and its Principles. Learn from the best in the industry.',
        tags: ['Design', 'Research'],
      },
      {
        id: 6,
        image: '/assets/images/blog-img-3.png',
        date: 'Natali Craig • 14 Jan 2022',
        title: 'UX review presentations',
        content: 'How do you create compelling presentations that wow your colleagues and impress your...',
        tags: ['Design', 'Research', 'Frameworks'],
      },
    // Add more blog items as needed
  ];

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 575,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <section className="blogSection">
      <div className="container">
        <h6 className="sectionTitle" data-aos="fade-up"
     data-aos-easing="linear"
     data-aos-duration="1500">Blog</h6>
        <h3 className="textboldTitle mb-2" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1500">our latest articles</h3>
        <Slider {...settings}>
          {blogData.map((blogItem) => (
            <div key={blogItem.id} className="blog-item">
              <div className="blog-img">
                <img src={process.env.PUBLIC_URL + blogItem.image} alt="blog image" />
              </div>
              <div className="blog-detail">
                <p className="blogDate">{blogItem.date}</p>
                <p className="blog-title">{blogItem.title}</p>
                <p className="paragraph">{blogItem.content}</p>
                <ul className="tagg">
                  {blogItem.tags.map((tag, index) => (
                    <li key={index}>
                      <a href="javascript:void(0)" className={tag}>{tag}</a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </Slider>
      </div>
      <img src={process.env.PUBLIC_URL + '/assets/images/blog-vector.png'} className='blog-vector' alt='blog image' />
    </section>
  );
};

export default Blog;
