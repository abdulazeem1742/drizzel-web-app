import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

export default function Homebanner() {
    // const styles = {
    //     background: `url(${process.env.PUBLIC_URL}/assets/images/home_banner.png)`,
    //     backgroundSize: 'cover',
    //     backgroundPosition: 'center',
    //     height: '100vh',
    //   };
    useEffect(() => {
        AOS.init({
          // Global settings and options
        });
      }, []); // Run only once when the component mounts
    
  return (
    <section className='homeBanner'>
        <div className='container'>
            <div className='banner-content' data-aos="fade-up" data-aos-anchor-placement="top-bottom"> 
                <h6 className='sectionTitle'>Drizzel Creative Agency</h6>
                <h3 className='textboldTitle'>digital agency with solid design</h3>
                <div className='desc_sect d_flexStartBetween' data-aos="fade-up" data-aos-duration="3000">
                    <div className='desc_content'>
                        <p className='num'>13+</p>
                        <p className='paragraph'>years of experience</p>
                    </div>
                    <div className='desc_content'>
                        <p className='num'>74k+</p>
                        <p className='paragraph'>Project Completed</p>
                    </div>
                    <div className='desc_content'>
                        <p className='num'>9.2k+</p>
                        <p className='paragraph'>Trusted Companies</p>
                    </div>
                    <img src={process.env.PUBLIC_URL + '/assets/images/Union.png'} className='Union' alt='Union image' />
                    <img src={process.env.PUBLIC_URL + '/assets/images/Subtract.png'} className='Subtract' alt='Subtract image' />
                </div>
            </div>
        </div>
        <img src={process.env.PUBLIC_URL + '/assets/images/vector_1.png'} className='vector_1' alt='vector image' />
        <img src={process.env.PUBLIC_URL + '/assets/images/vector_2.png'} className='vector_2' alt='vector image' />
        <img src={process.env.PUBLIC_URL + '/assets/images/vector_3.png'} className='vector_3' alt='vector image' />
        <img src={process.env.PUBLIC_URL + '/assets/images/vector_4.png'} className='vector_4' alt='vector image' />
    </section>
  )
}
