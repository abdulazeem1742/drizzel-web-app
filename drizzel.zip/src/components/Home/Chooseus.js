import React from 'react'

export default function Chooseus() {
  return (
    <section className='chooseSection'>
        <div className='container'>
            <div className='row'>
                <div className='col-12 col-md-6 col-lg-6'>
                    <div className='chooseUs_img'>
                        <img src={process.env.PUBLIC_URL + '/assets/images/why-choose-img.png'} alt='choose us' />
                    </div>
                </div>
                <div className='col-12 col-md-6 col-lg-6'>
                    <div className='chooseUs_content'>
                        <h6 className='sectionTitle'>why choose us</h6>
                        <h3 className='textboldTitle' data-aos="fade-down"
                            data-aos-easing="linear"
                            data-aos-duration="1500">creating beatiful design based on client needs</h3>
                        <p className='paragraph'>Es ist ein lang erwiesener Fakt, dass ein Leser vom Text wird, wenn er sich ein Layout ansieht.</p>
                        <ul className='chooseUs_listing' data-aos="fade-up"
                            data-aos-anchor-placement="top-bottom">
                            <li>
                                <span className='socialIcon'>
                                    <img src={process.env.PUBLIC_URL + '/assets/images/phone.png'} alt='choose us' />
                                </span>
                                <div className='choose_detail'>
                                    <p className='choose-title'>Amazing Designs</p>
                                    <p className='paragraph'>Es ist ein lang erwiesener Fakt, dass ein Leser vom Text wird, wenn er sich ein Layout ansieht.</p>
                                </div>
                            </li>
                            <li>
                                <span className='socialIcon'>
                                    <img src={process.env.PUBLIC_URL + '/assets/images/user.png'} alt='choose us' />
                                </span>
                                <div className='choose_detail'>
                                    <p className='choose-title'>Dedicated Team</p>
                                    <p className='paragraph'>Es ist ein lang erwiesener Fakt, dass ein Leser vom Text wird, wenn er sich ein Layout ansieht.</p>
                                </div>
                            </li>
                            <li>
                                <span className='socialIcon'>
                                    <img src={process.env.PUBLIC_URL + '/assets/images/Star.png'} alt='choose us' />
                                </span>
                                <div className='choose_detail'>
                                    <p className='choose-title'>24/7 Support</p>
                                    <p className='paragraph'>Es ist ein lang erwiesener Fakt, dass ein Leser vom Text wird, wenn er sich ein Layout ansieht.</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <img src={process.env.PUBLIC_URL + '/assets/images/choose-vector.png'} className='chooseVector' alt='choose us' />
    </section>
  )
}
