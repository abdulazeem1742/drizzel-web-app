import React from 'react'
import Homebanner from './Homebanner'
import Development from './Development'
import Logos from './Logos'
import Portfolio from './Portfolio'
import Chooseus from './Chooseus'
import TestimonialSlider from './Testimonial'
import Blog from './Blog'
import ContactSection from './ContactSection'

export default function Home() {
  return (
    <div id="your-scroll-container">
    <Homebanner />
    <Development />
    <Logos />
    <Portfolio />
    <Chooseus />
    <TestimonialSlider />
    <Blog />
    <ContactSection />
    </div>
  )
}
