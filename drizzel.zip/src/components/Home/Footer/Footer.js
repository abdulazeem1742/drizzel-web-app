import React from 'react'

export default function Footer() {
  return (
    <footer id="your-footer" className='footer'>
        <div className='container'>
            <div className='row'>
                <div className='col-12 col-md-4 col-lg-4'>
                    <a href='javascript:void(0)' className='ft_logo'>
                    <img src={process.env.PUBLIC_URL + '/assets/images/Drizzel.png'} alt='drizzel logo' />
                    </a>
                </div>
                <div className='col-12 col-md-4 col-lg-4'>
                    <div className='ft_social'>
                        <p className='ft_title'>Find Us On Social Media:</p>
                        <ul className='ft-social-icon'> 
                            <li>
                                <a>
                                    <img src={process.env.PUBLIC_URL + '/assets/images/Facebook.png'} alt='facebook' />
                                </a>
                            </li>
                            <li>
                                <a>
                                    <img src={process.env.PUBLIC_URL + '/assets/images/Twitter.png'} alt='twitter' />
                                </a>
                            </li>
                            <li>
                                <a>
                                    <img src={process.env.PUBLIC_URL + '/assets/images/Instagram.png'} alt='instagram' />
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div className='col-12 col-md-4 col-lg-4'>
                    <div className='ft_social'>
                        <p className='ft_title'>We’re Always Happy To Help</p>
                        <a href='mail:to()'>uifry@gmail.com</a>
                    </div>
                </div>
                <div className='col-12 copyRight'>
                    <p className='paragraph'>Copyright © 2023 Drizzel</p>
                </div>
            </div>
        </div>
        <img src={process.env.PUBLIC_URL + '/assets/images/ft_vector.png'} className='ft_vector' alt='footer vector image' />
    </footer>
  )
}
