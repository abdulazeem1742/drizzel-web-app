import React from 'react'

export default function ContactSection() {
  return (
    <section className='contactSection'>
        <div className='container'>
            <div className='contact_content'>
                <h3 className='textboldTitle' data-aos="fade-down"
                    data-aos-easing="linear"
                    data-aos-duration="1500">Ready to start a project with us?</h3>
                <div className='inputField'>
                    <input type='email' placeholder='Enter your email address' />
                    <a href='javascript:void(0)' className='cta'>Get Started</a>
                </div>
            </div>
        </div>
    </section>
  )
}
