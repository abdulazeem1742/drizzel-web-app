import React from 'react'

export default function Development() {
  return (
    <div className="marquee">
  <span className="marquee-item">
    <img src={process.env.PUBLIC_URL + '/assets/images/Union.png'} alt='Union image' /> WEB DESIGN
  </span>
  <span className="marquee-item">
    <img src={process.env.PUBLIC_URL + '/assets/images/Union.png'} alt='Union image' /> APP DESIGN
  </span>
  <span className="marquee-item">
    <img src={process.env.PUBLIC_URL + '/assets/images/Union.png'} alt='Union image' /> LOGO DESIGN
  </span>
  <span className="marquee-item">
    <img src={process.env.PUBLIC_URL + '/assets/images/Union.png'} alt='Union image' /> UI/UX DESIGN
  </span>
  
  {/* Duplicate the spans to create a continuous scroll */}
  <span className="marquee-item">
    <img src={process.env.PUBLIC_URL + '/assets/images/Union.png'} alt='Union image' /> WEB DESIGN
  </span>
  <span className="marquee-item">
    <img src={process.env.PUBLIC_URL + '/assets/images/Union.png'} alt='Union image' /> APP DESIGN
  </span>
  <span className="marquee-item">
    <img src={process.env.PUBLIC_URL + '/assets/images/Union.png'} alt='Union image' /> LOGO DESIGN
  </span>
  <span className="marquee-item">
    <img src={process.env.PUBLIC_URL + '/assets/images/Union.png'} alt='Union image' /> UI/UX DESIGN
  </span>
</div>

  
  )
}
