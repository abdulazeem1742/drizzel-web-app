import React from 'react'

export default function Portfolio() {
  return (
    <section className='portfolioSection'>
        <h6 className='sectionTitle' data-aos="fade-up"
            data-aos-duration="3000">Portfolio</h6>
        <h3 className='textboldTitle' data-aos="fade-down"
            data-aos-easing="linear"
            data-aos-duration="1500">our latest projects</h3>
        <div className='row mt-5'>
            <div className='col-12 col-md-2 col-lg-3 mb-3'>
                <div className='portfoliomg'>
                    <img src={process.env.PUBLIC_URL + '/assets/images/portfolio_img_1.png'} alt='portfolio image' />
                </div>
            </div>
            <div className='col-12 col-md-4 col-lg-4 mb-3'>
                <div className='portfoliomg'>
                    <img src={process.env.PUBLIC_URL + '/assets/images/portfolio_img_2.png'} alt='portfolio image' />
                </div>
            </div>
            <div className='col-12 col-md-4 col-lg-4 mb-3'>
                <div className='portfoliomg'>
                    <img src={process.env.PUBLIC_URL + '/assets/images/portfolio_img_3.png'} alt='portfolio image' />
                </div>
            </div>
            <div className='col-12 col-md-2 col-lg-1 mb-3'>
                <div className='portfoliomg'>
                    <img src={process.env.PUBLIC_URL + '/assets/images/portfolio_img_4.png'} alt='portfolio image' />
                </div>
            </div>
            <div className='col-12 col-md-2 col-lg-1'>
                <div className='portfoliomg'>
                    <img src={process.env.PUBLIC_URL + '/assets/images/portfolio_img_5.png'} alt='portfolio image' />
                </div>
            </div>
            <div className='col-12 col-md-4 col-lg-4'>
                <div className='portfoliomg'>
                    <img src={process.env.PUBLIC_URL + '/assets/images/portfolio_img_6.png'} alt='portfolio image' />
                </div>
            </div>
            <div className='col-12 col-md-4 col-lg-4'>
                <div className='portfoliomg'>
                    <img src={process.env.PUBLIC_URL + '/assets/images/portfolio_img_7.png'} alt='portfolio image' />
                </div>
            </div>
            <div className='col-12 col-md-2 col-lg-3'>
                <div className='portfoliomg'>
                    <img src={process.env.PUBLIC_URL + '/assets/images/portfolio_img_8.png'} alt='portfolio image' />
                </div>
            </div>
            <div className='col-12 mt-3 viewMore'>
                <a href='javascript:void(0)' className='cta'>View more</a>
            </div>
        </div>
        <img src={process.env.PUBLIC_URL + '/assets/images/Subtract.png'} className='Subtract' alt='vector image' />
        <img src={process.env.PUBLIC_URL + '/assets/images/vector_1.png'} className='vector_1' alt='vector image' />
        <img src={process.env.PUBLIC_URL + '/assets/images/vector_2.png'} className='vector_2' alt='vector image' />
    </section>
  )
}
