import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const TestimonialSlider = () => {
  const testimonials = [
    {
      id: 1,
      photo: '/assets/images/testimonial_img1.png',
      ratings: [1, 2, 3, 4, 5],
      content: '“Es ist ein lang erwiesener Fakt, dass ein Leser vom Text abgelenkt wird, wenn er sich ein Layout ansieht. Der Punkt, Lorem Ipsum zu nutzen.”',
      userName: 'Jenny Wilson',
      company: 'Grower.io',
    },
    {
        id: 2,
        photo: '/assets/images/testimonial_img2.png',
        ratings: [1, 2, 3, 4, 5],
        content: '“Es ist ein lang erwiesener Fakt, dass ein Leser vom Text abgelenkt wird, wenn er sich ein Layout ansieht. Der Punkt, Lorem Ipsum zu nutzen.”',
        userName: 'Devon Lane',
        company: 'DLDesign.co',
      },
      {
        id: 3,
        photo: '/assets/images/testimonial_img1.png',
        ratings: [1, 2, 3, 4, 5],
        content: '“Es ist ein lang erwiesener Fakt, dass ein Leser vom Text abgelenkt wird, wenn er sich ein Layout ansieht. Der Punkt, Lorem Ipsum zu nutzen.”',
        userName: 'Jenny Wilson',
        company: 'Grower.io',
      },
      {
          id: 4,
          photo: '/assets/images/testimonial_img2.png',
          ratings: [1, 2, 3, 4, 5],
          content: '“Es ist ein lang erwiesener Fakt, dass ein Leser vom Text abgelenkt wird, wenn er sich ein Layout ansieht. Der Punkt, Lorem Ipsum zu nutzen.”',
          userName: 'Devon Lane',
          company: 'DLDesign.co',
        },
    // Add more testimonials as needed
  ];

  var settings = {
      infinite: true,
    dots: true,
    speed: 500,
    slidesToShow: 2,
    slidesToScroll: 1,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };

  return (
    <section className='testimonialSlider'>
        <h6 className='sectionTitle' data-aos="fade-up"
            data-aos-duration="3000">Testimonials</h6>
        <h3 className='textboldTitle' data-aos="fade-down"
        data-aos-easing="linear"
        data-aos-duration="1500">our beloved clients</h3>
      <div className='testimonial-SliderContent mt-5'>
        <Slider {...settings}>
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className='testimonialBox'>
              <div className='photo'>
                <img src={process.env.PUBLIC_URL + testimonial.photo} alt='testimonial image' />
              </div>
              <div className='testimonial_detail'>
                <a href="javascript:void(0)" className='ratingStar'>
                  {testimonial.ratings.map((rating, index) => (
                    <img key={index} src={process.env.PUBLIC_URL + '/assets/images/rating.png'} alt='rating star' />
                  ))}
                </a>
                <p className='paragraph'>{testimonial.content}</p>
                <p className='user_name'>{testimonial.userName} <span>{testimonial.company}</span></p>
              </div>
            </div>
          ))}
        </Slider>
      </div>
      <img src={process.env.PUBLIC_URL + '/assets/images/testimonial-vector.png'} className='testimonial-vector' alt='Union image' />
    </section>
  );
};

export default TestimonialSlider;
